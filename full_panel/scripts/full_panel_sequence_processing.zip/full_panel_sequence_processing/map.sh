#!/bin/bash
#   This file is part of the analysis for the publication 'CRISPR-directed mitotic recombination 
#   enables genetic mapping without crosses'. Code written by Joshua S Bloom.
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.


# Note! Processing miseq new nested directories
# pull from one set of nested directories to one directory
# for example \data\calls\1\Intensities\1.fqL \data\calls\1\Intensities\1.fqR
#              \data\calls\2\Intensities\2.fqL \data\calls\2\Intensities\2.fqR
# to \data\1.fqL  \data\2.fqL \data\1.fqR  ...etc
# 
# the magic is :
#>  find MS_1_and_MS_4_crispr_LOH_chrVII-21758740/  -type f -iname '*.fastq.gz' -exec mv {} fastq/ \;
#
#used GPRename to clean up miseq file name ... this isn't strictly necessary just makes postprocessing sample names less annoying

#Program: bwa (alignment via Burrows-Wheeler transformation)
#Version: 0.7.5a-r405

#Program: samtools (Tools for alignments in the SAM format)
#Version: 0.1.19-96b5f2294a

# Program: picard
#Version: 1.130(8b3e8abe25f920f5aa569db482bb999f29cc447b_1427207353)
# create an alias in your .bashrc , for example:
#alias picard='java -jar /home/jbloom/Local/picard-tools-1.130/picard.jar'

#Program: gatk
#Version: 3.3-0-geee94ec
# create an alias in your .bashrc , for example:
# alias gatk='java -d64 -Xms2g -Xmx4g -jar /home/jbloom/Local/gatk-protected/target/GenomeAnalysisTK.jar'

#Program: trimmotatic
#Version: 0.32
# create an alias in your .bashrc , for example:
# alias='java -jar /home/jbloom/Local/Trimmomatic-0.32/trimmomatic-0.32.jar'

# genome downloaded from sgd but manually resorted chrI ... chrXVI chrM in order(!) and CAS9 plasmids
# chromosome order is very important for use of GATK 
# or ensembl VEP
# and annoying to deal with later on if it isn't sorted

# set some variables:
genome='/data/CRISPR_LOH/Reference/ucsc_sacCer3/sacCer3_CRISPR.fasta'
root_dir='/data/CRISPR_LOH/03/'
merged_bam="${root_dir}MS_chrVII_1234.bam"
output="${root_dir}MS_chrVII_1234"
output_vcf="${output}.vcf"

fastq_dir="${root_dir}fastq/"
bam_dir="${root_dir}bam/"
adapter_file='/data/CRISPR_LOH/Nextera_primers_PE.fa'
# list of sample names (no file extension)
snames=(`cat "${root_dir}MS_1234.list" `)

# set to number of threads on your cpu 
cputhreads=11
# Run once ---------------------------------------------------------------------------------
# make sure index and dict exist for reference fasta files
# create fasta index
# important! run these in the directory of your reference genome------------
samtools faidx sacCer3_CRISPR.fasta 
bwa index sacCer3_CRISPR.fasta
#----------------------------------------------------------------------------
# create sequence dictionary (for GATK only)
picard CreateSequenceDictionary \
    REFERENCE=/data/CRISPR_LOH/Reference/ucsc_sacCer3/sacCer3_CRISPR.fasta \
    OUTPUT=/data/CRISPR_LOH/Reference/ucsc_sacCer3/sacCer3_CRISPR.dict
#----------------------------------------------------------------------------------------------

mkdir $fastq_dir
mkdir $bam_dir

echo $fastq_dir
echo $bam_dir

# Read trimming (remove adapters and convert to PHRED33) -------------------------------------------------------------------------
# note, this is for PE reads ... adjust for SE reads
for samp in ${snames[@]}
do
        trimmomatic PE -threads $cputhreads \
        ${fastq_dir}/${samp}_R1.fastq.gz   ${fastq_dir}/${samp}_R2.fastq.gz \
        ${fastq_dir}/${samp}_t_R1.fastq.gz ${fastq_dir}/${samp}_R1_up.fastq.gz \
        ${fastq_dir}/${samp}_t_R2.fastq.gz ${fastq_dir}/${samp}_R2_up.fastq.gz \
        ILLUMINACLIP:${adapter_file}:2:20:10 LEADING:0 TRAILING:0 SLIDINGWINDOW:0:0 MINLEN:30 TOPHRED33
done
#----------------------------------------------------------------------------------------------------------------------------------


# Iterate through samples and align with bwa --------------------------------------------------------------------------------------
# filter on uniquely mapping reads and sort
# Set -t to be number of threads your machine is capable of running
# output a sorted bam file
for t in  ${snames[@]}
    do 
    echo $t
    # note, this is for PE reads ... adjust for SE reads
    bwa mem -t $cputhreads ${genome} "${fastq_dir}${t}_t_R1.fastq.gz" "${fastq_dir}${t}_t_R2.fastq.gz" | \
    samtools view -hSuq 1 - | \
    samtools sort - ${bam_dir}${t}
done
#-----------------------------------------------------------------------------------------------------------------------------------

# Create a merged bam for all of your samples -------------------------------------------------------------
cd $root_dir
# create a header
sed MS_1234.list -e 's/\(.*\)/@RG\tID:\1\tSM:\1/g' | cat ref_contigs_header.sam - > header.sam
# merge bam files, attach @RG flad to each read and attach new header
samtools merge -r -h header.sam $merged_bam $bam_dir/*.bam
# index bam file (necessary for variant calling)
samtools index $merged_bam
#------------------------------------------------------------------------------------------------------------


# two options for variant calling
#1) SAMtools VCF generation --------------------------------------------------------------------------------
# previous version with samtools mpileup
# parallelized mpileup
#samtools view -H BYxRM_CRISPR.bam | grep "\@SQ" | sed 's/^.*SN://g' | \
#    cut -f 1 | xargs -I {} -n 1 -P 11 \
#    sh -c "samtools mpileup -d 100000 -D -uf $genome \
#         -r {} BYxRM_CRISPR.bam | bcftools view -Ncgv -P flat - > tmp.{}.vcf"
# reassemble chromosome vcfs into one vcf
# chr is a filename with chromosomes
#chrs=(`cat "/data/CRISPR_LOH/Reference/chr" `)
#for t in "${chrs[@]}"
#        do  
#        cat tmp.$t.vcf >> $output_vcf
#done

#single thread mpileup
# -d specifies downsampling...don't downsample set this high
samtools mpileup -d 100000 -D -uf $genome $merged_bam | bcftools view -Ncgv -P flat > $output_vcf
vcftools --vcf $output_vcf --out $output --min-alleles 2 --max-alleles 2 --minQ 900 --minGQ 30  --keep-INFO-all --recode

# for directly loading in vcf as a table to R uncomment out header line
#sed -i 's/#CHROM/CHROM/g' $output_vcf



#2) GATK VCFs ---------------------------------------------------------------------------------------------
#  note: investigate haplotypeCaller for haploid samples and any important de-novo variant calling
#  given --sample_ploidy option is now available there
# -dcov downsamples to 250 reads per site by default, this is very dangerous. Increase as necessary
# -nt sets number of threads for processing
# - comp adds a 'comp' flag in INFO for variants that match in a reference VCF file
# this does SNPs only
gatk -R  /data/CRISPR_LOH/Reference/ucsc_sacCer3/sacCer3_CRISPR.fasta \
     -T UnifiedGenotyper \
     -I $merged_bam \
     -o $output_vcf \
     -stand_call_conf 50.0 \
     -stand_emit_conf 10.0 \
     -dcov 5000 \
     -nt $cputhreads \
     --sample_ploidy 2 \
     -comp /data/CRISPR_LOH/Reference/RM.var.flt.MoreIndels.vcf 
vcftools --vcf $output_vcf --out $output --min-alleles 2 --max-alleles 2 --minQ 900 --minGQ 30  --keep-INFO-all --recode
#----------------------------------------------------------------------------------------------------------
